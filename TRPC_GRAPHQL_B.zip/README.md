# Express, Prisma, tRPC starter project

This is a simple web server that uses Express, Prisma, tRPC, all together with TypeScript to provide the best experience when starting new backend projects.
